<?php

namespace App\Http\Controllers;

use App\BatchRoute;
use App\Item;
use App\Product;
use App\Station;
use App\StationLog;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Collection;
use DNS1D;

class ItemController extends Controller
{

	private $statuses = [
		'active'      => 'Active',
		'not started' => 'Not started',
		'completed'   => 'Completed',
	];

	public function index (Request $request)
	{
		$items = Item::with('order.customer', 'store', 'route.stations_list')
					 ->where('is_deleted', 0)
					 ->search($request->get('search_for'), $request->get('search_in'))
					 ->latest()
					 ->paginate(50);

		$unassigned = Item::whereNull('batch_number')
						  ->where('is_deleted', 0)
						  ->count();
		$unassignedProductCount = Product::whereNull('batch_route_id')
										 ->where('is_deleted', 0)
										 ->count();
		$search_in = [
			'all'                 => 'All',
			'order'               => 'Order',
			'order_date'          => 'Order date',
			'store_id'            => 'Store',
			'state'               => 'State',
			'description'         => 'Description',
			'item_id'             => 'SKU',
			'batch'               => 'Batch',
			'batch_creation_date' => 'Batch Creation date',
		];

		#return $items;
		return view('items.index', compact('items', 'search_in', 'request', 'unassigned', 'unassignedProductCount'));
	}

	public function getBatch ()
	{
		$count = 1;
		$serial = 1;
		$batch_routes = BatchRoute::with([
			'stations_list',
			'itemGroups' => function ($q) {
				return $q->join('items', 'products.id_catalog', '=', 'items.item_id')
						 ->where('items.is_deleted', 0)
						 ->whereNull('items.batch_number')
						 ->join('orders', 'orders.order_id', '=', 'items.order_id')
						 ->where('orders.is_deleted', 0)
						 ->addSelect([
							 DB::raw('items.id AS item_table_id'),
							 'items.item_id',
							 'items.order_id',
							 'items.item_quantity',
							 DB::raw('orders.id as order_table_id'),
							 'orders.order_id',
							 'orders.order_date',
						 ]);
			},
		])
								  ->where('batch_routes.is_deleted', 0)
								  ->get();

		#return $batch_routes;

		return view('items.create_batch', compact('batch_routes', 'count', 'serial'));
	}

	public function postBatch (Request $request)
	{
		$today = date('ymd', strtotime('now'));
		$batches = $request->get('batches');

		$acceptedGroups = [ ];
		/*
		 * $max_batch_id = 0;
		 * $last_assigned_batch = Item::whereNotNull('batch_number')
								   ->latest()
								   ->first();
		if ( $last_assigned_batch ) {
			$max_batch_id = explode("~", $last_assigned_batch->batch_number)[2];
		}*/

		$items = Item::where('batch_number', 'LIKE', sprintf("%s%%", $today))
					 ->groupBy('batch_number')
					 ->get();
		$last_batch_number = count($items);
		$current_group = -1;

		foreach ( $batches as $preferredBatch ) {
			list( $inGroup, $batch_route_id, $item_id ) = explode("|", $preferredBatch);
			if ( $inGroup != $current_group ) {
				#$max_batch_id++;
				$last_batch_number++;
				$current_group = $inGroup;
			}
			#$batch_code = BatchRoute::find($batch_route_id)->batch_code;
			#$proposedBatch = sprintf("%s~%s~%s", $today, $batch_code, $max_batch_id);
			$proposedBatch = sprintf("%s%04d", $today, $last_batch_number);

			$acceptedGroups[$inGroup][] = [
				$item_id,
				$proposedBatch,
				$batch_route_id,
			];
		}

		#return $acceptedGroups;
		foreach ( $acceptedGroups as $groups ) {
			foreach ( $groups as $itemGroup ) {
				$item_id = $itemGroup[0];
				$batch_number = $itemGroup[1];
				$batch_route_id = $itemGroup[2];

				$item = Item::find($item_id);
				$item->batch_number = $batch_number;
				$item->batch_route_id = $batch_route_id;
				$batch = BatchRoute::with('stations_list')
								   ->find($batch_route_id);
				$station_id = $batch->stations_list[0]->station_id;
				$station_name = $batch->stations_list[0]->station_name;
				$item->station_name = $station_name;
				$item->item_order_status = 'active';
				$item->batch_creation_date = date('Y-m-d H:i:s', strtotime('now'));
				$item->save();

				$station_log = new StationLog();
				$station_log->item_id = $item_id;
				$station_log->batch_number = $batch_number;
				$station_log->station_id = $station_id;
				$station_log->started_at = date('Y-m-d h:i:s', strtotime("now"));
				$station_log->save();

			}
		}

		return redirect(url('items/grouped'));
	}

	public function getGroupedBatch (Request $request)
	{
		$items = Item::with('order', 'route.stations_list', 'groupedItems')
					 ->whereNotNull('batch_number')
					 ->searchBatch($request->get('batch'))
					 ->searchRoute($request->get('route'))
					 ->searchStation($request->get('station'))
					 ->searchStatus($request->get('status'))
					 ->groupBy('batch_number')
					 ->latest('batch_creation_date')
					 ->paginate(50);

		$routes = BatchRoute::where('is_deleted', 0)
							->latest()
							->lists('batch_route_name', 'id')
							->prepend('Select a route', 'all');

		$stations = Station::where('is_deleted', 0)
						   ->latest()
						   ->lists('station_description', 'id')
						   ->prepend('Select a station', 'all');

		$statuses = (new Collection($this->statuses))->prepend('Select status', 'all');

		return view('routes.index', compact('items', 'request', 'routes', 'stations', 'statuses'));
		/*$itemGroups = Item::with('groupedItems', 'order')
						  ->where('is_deleted', 0)
						  ->whereNotNull('batch_number')
						  ->groupBy('batch_number')
						  ->latest('batch_creation_date')
						  ->paginate(50);

		#return $itemGroups;
		$count = 1;
		$serial = 1;

		return view('items.item_groups', compact('itemGroups', 'count', 'serial'));*/
	}

	public function getBatchItems ($batch_number)
	{
		$items = Item::with('order')
					 ->where('batch_number', $batch_number)
					 ->get();
		if ( !count($items) ) {
			return view('errors.404');
		}
		$bar_code = DNS1D::getBarcodeHTML($batch_number, "C39");
		$statuses = $this->statuses;
		$route = BatchRoute::with('stations')
						   ->find($items[0]->batch_route_id);

		$stations = implode(" > ", array_map(function ($elem) {
			return $elem['station_name'];
		}, $route->stations->toArray()));

		#return $items;

		return view('routes.show', compact('items', 'bar_code', 'batch_number', 'statuses', 'route', 'stations'));
	}

	public function updateBatchItems (Request $request, $batch_number)
	{
		$items = Item::where('batch_number', $batch_number)
					 ->get();

		if ( $request->has('status') ) {
			$status = $request->get('status');
			if ( !count($items) || !$status || !array_key_exists($status, $this->statuses) ) {
				return redirect()->back();
			}

			foreach ( $items as $item ) {
				$item->item_order_status = $request->get('status');
				$item->save();
			}
		} elseif ( $request->has('station') ) {
			$station = Station::where('station_name', $request->get('station'))->first();
			$station_name = $station->station_name;
			foreach ( $items as $item ) {
				$item->station_name = $station_name;
				$item->save();
			}
		}

		return redirect()->back();
	}
}
