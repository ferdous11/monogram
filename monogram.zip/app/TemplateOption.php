<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TemplateOption extends Model
{
	protected $table = 'template_options';
}
